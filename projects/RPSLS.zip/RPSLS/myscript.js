const canvas = document.getElementById('myCanvas');
const ctx = canvas.getContext('2d');

let gameState = 'menu'; // menu, info, countDown, winner
let keyCount = 0;
let player1 = 'none'; // rock, paper, scissor, lizard, spock
let player2 = 'none'; // rock, paper, scissor, lizard, spock
let winner = 'none'; // Player 1, Player 2, Draw
let p1_score = 0;
let p2_score = 0;

const rock = new Image();
const paper = new Image();
const scissors = new Image();
const lizard = new Image();
const spock = new Image();
rock.src = "rock.png";
paper.src = "paper.png";
scissors.src = "scissors.png";
lizard.src = "lizard.png";
spock.src = "spock.png";

const keyMapping = {
    q: 'rock',
    w: 'paper',
    e: 'scissors',
    r: 'lizard',
    t: 'spock',
    y: 'rock',
    u: 'paper',
    i: 'scissors',
    o: 'lizard',
    p: 'spock'
};

function setUpClickListener() {
    canvas.addEventListener('click', handleClick);
}
function removeClickListener() {
    canvas.removeEventListener('click', handleClick);
}
function setUpPress() {
    document.addEventListener('keydown', handlePress);
}
function handleClick(event) {
    const rect = canvas.getBoundingClientRect();
    const mouseX = event.clientX - rect.left;
    const mouseY = event.clientY - rect.top;
    console.log('mouseX: ' + mouseX + 'mouseY: ' + mouseY);

    if (gameState == 'menu') {
        if (mouseX >= 180 && mouseX <= 273 && mouseY >= 254 && mouseY <= 352) {
            console.log("play button");
            gameState = 'countDown';
            gameLoop();
        }
        else if (mouseX >= 324 && mouseX <= 423 && mouseY >= 254 && mouseY <= 352) {
            console.log("game info button");
            gameState = 'info';
            gameLoop();
        }
    }
    else if(gameState === 'info'){
        if (mouseX >= 194 && mouseX <= 405 && mouseY >= 412 && mouseY <= 474) {
            console.log("back to main menu");
            gameState = 'menu';
            gameLoop();
        }
    }
    else if (gameState === 'winner') {
        if (mouseX >= 133 && mouseX <= 413 && mouseY >= 312 && mouseY <= 392) {
            console.log("Play again");
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            gameState = 'countDown';
            keyCount = 0;
            player1 = 'none'; // rock, paper, scissor, lizard, spock
            player2 = 'none'; // rock, paper, scissor, lizard, spock
            winner = 'none'; // Player 1, Player 2, Draw
            gameLoop();
        }
        else if (mouseX >= 154 && mouseX <= 420 && mouseY >= 411 && mouseY <= 492) {
            console.log("Main Menu");
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            gameState = 'menu';
            keyCount = 0;
            player1 = 'none'; // rock, paper, scissor, lizard, spock
            player2 = 'none'; // rock, paper, scissor, lizard, spock
            winner = 'none'; // Player 1, Player 2, Draw
            p1_score = 0;
            p2_score = 0;
            gameLoop();

        }
    }
}
// UPDATED
function chooseTimer() {
    removeClickListener();
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.font = '100px Pixelify Sans';
    ctx.fillStyle = 'green';

    const countdown = ['  3', '  2', '  1', 'GO!'];

    countdown.forEach((text, index) => {
        setTimeout(() => {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.font = '100px Pixelify Sans';
            ctx.fillText(text, 235, 180);
            if (text === 'GO!') {
                setUpPress();
            } else {
                displayOptions();
            }
        }, index * 1000 + 500);
    });
}

/* function chooseTimer() {
    removeClickListener();
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    setTimeout(() => {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.font = '100px Pixelify Sans';
        ctx.fillStyle = 'green';
        ctx.fillText('3', 250, 180);
        displayOptions();
    }, 500);
    setTimeout(() => {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.font = '100px Pixelify Sans';
        ctx.fillStyle = 'green';
        ctx.fillText('2', 250, 180);
        displayOptions();
    }, 2000);
    setTimeout(() => {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.font = '100px Pixelify Sans';
        ctx.fillStyle = 'green';
        ctx.fillText('1', 250, 180);
        displayOptions();
        console.log('timer worked!');
    }, 3000);
    setTimeout(() => {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.font = '200px Pixelify Sans';
        ctx.fillStyle = 'green';
        ctx.fillText('GO!!!', 100, 180);
        setUpPress(); // checks the two keys that were pressed 
    }, 4000);
    //set up event listener
    // so when two players press the keys at the same time
    //it will register both keys
    //also create an automation for player 2
} */

function displayOptions() {
    ctx.fillStyle = 'green';
    ctx.font = '30px Pixelify Sans';
    //player one options and control
    ctx.fillRect(10, 5, 60, 60);
    ctx.fillText('Rock', 10, 90);
    ctx.fillRect(10, 100, 60, 60);
    ctx.fillText('Paper', 10, 185);
    ctx.fillRect(10, 200, 60, 60);
    ctx.fillText('Scissors', 10, 285);
    ctx.fillRect(10, 300, 60, 60);
    ctx.fillText('Lizard', 10, 385);
    ctx.fillRect(10, 400, 60, 60);
    ctx.fillText('Spock', 10, 485);
    //player 2 options and control
    ctx.fillRect(535, 5, 60, 60);
    ctx.fillText('Rock', 520, 90);
    ctx.fillRect(535, 100, 60, 60);
    ctx.fillText('Paper', 510, 185);
    ctx.fillRect(535, 200, 60, 60);
    ctx.fillText('Scissors', 470, 285);
    ctx.fillRect(535, 300, 60, 60);
    ctx.fillText('Lizard', 500, 385);
    ctx.fillRect(535, 400, 60, 60);
    ctx.fillText('Spock', 510, 485);
    ctx.drawImage(rock, 10, 5, 60, 60);
    ctx.drawImage(rock, 535, 5, 60, 60);
    ctx.drawImage(paper, 10, 100, 60, 60);
    ctx.drawImage(paper, 535, 100, 60, 60);
    ctx.drawImage(scissors, 10, 200, 60, 60);
    ctx.drawImage(scissors, 535, 200, 60, 60);
    ctx.drawImage(lizard, 10, 300, 60, 60);
    ctx.drawImage(lizard, 535, 300, 60, 60);
    ctx.drawImage(spock, 10, 400, 60, 60);
    ctx.drawImage(spock, 535, 400, 60, 60);
    ctx.fillText('Q', 80, 45);
    ctx.fillText('W', 80, 145);
    ctx.fillText('E', 80, 245);
    ctx.fillText('R', 80, 345);
    ctx.fillText('T', 80, 445);
    ctx.fillText('Y', 510, 45);
    ctx.fillText('U', 510, 145);
    ctx.fillText('I', 510, 245);
    ctx.fillText('O', 510, 345);
    ctx.fillText('P', 510, 445);
}
// UPDATED avoided redundancy by using an if statement
// also mapped the key pressed 
function handlePress(event, callback) {
    if (keyCount < 2) { //this is all the events for player 1 and 2
        const choice = keyMapping[event.key];
        if (choice) {
            if (['q', 'w', 'e', 'r', 't'].includes(event.key)) {
                if(player1 === 'none'){
                    player1 = choice;
                    keyCount++;
                }
            } else {
                if(player2 === 'none'){
                    player2 = choice;
                    keyCount++;
                }
            }
            
        }
        /* switch (event.key) {
            //player 1
            case 'q':
                console.log('Player 1: ');
                console.log('Rock');
                player1 = 'rock';
                keyCount += 1;
                break;
            case 'w':
                console.log('Player 1: ');
                console.log('Paper');
                keyCount += 1;
                player1 = 'paper';
                break;
            case 'e':
                console.log('Player 1: ');
                console.log('Scissors');
                keyCount += 1;
                player1 = 'scissors';
                break;
            case 'r':
                console.log('Player 1: ');
                console.log('Lizard');
                keyCount += 1;
                player1 = 'lizard';
                break;
            case 't':
                console.log('Player 1: ');
                console.log('Spock');
                keyCount += 1;
                player1 = 'spock';
                break;
            //player 2
            case 'y':
                console.log('Player 2: ');
                console.log('Rock');
                player2 = 'rock';
                keyCount += 1;
                break;
            case 'u':
                console.log('Player 2: ');
                console.log('Paper');
                keyCount += 1;
                player2 = 'paper';
                break;
            case 'i':
                console.log('Player 2: ');
                console.log('Scissors');
                keyCount += 1;
                player2 = 'scissors';
                break;
            case 'o':
                console.log('Player 2: ');
                console.log('Lizard');
                keyCount += 1;
                player2 = 'lizard';
                break;
            case 'p':
                console.log('Player 2: ');
                console.log('Spock');
                keyCount += 1;
                player2 = 'spock';
                break;
        } */
    }
    if (keyCount == 2) {
        checkWinner(); //if there were 2 selections games goes to check winner
    }

}
function checkWinner() {
    document.removeEventListener('keydown', handlePress);
    //player 1 wins
    if (player1 === 'scissors' && player2 === 'paper') {
        console.log('Player 1 wins!');
        winner = 'Player 1';
        p1_score += 1;
    }
    else if (player1 === 'paper' && player2 === 'rock') {
        console.log('Player 1 wins!');
        winner = 'Player 1';
        p1_score += 1;
    }
    else if (player1 === 'rock' && player2 === 'lizard') {
        console.log('Player 1 wins!');
        winner = 'Player 1';
        p1_score += 1;
    }
    else if (player1 === 'lizard' && player2 === 'spock') {
        console.log('Player 1 wins!');
        winner = 'Player 1';
        p1_score += 1;
    }
    else if (player1 === 'spock' && player2 === 'scissors') {
        console.log('Player 1 wins!');
        winner = 'Player 1';
        p1_score += 1;
    }
    else if (player1 === 'scissors' && player2 === 'lizard') {
        console.log('Player 1 wins!');
        winner = 'Player 1';
        p1_score += 1;
    }
    else if (player1 === 'lizard' && player2 === 'paper') {
        console.log('Player 1 wins!');
        winner = 'Player 1';
        p1_score += 1;
    }
    else if (player1 === 'paper' && player2 === 'spock') {
        console.log('Player 1 wins!');
        winner = 'Player 1';
        p1_score += 1;
    }
    else if (player1 === 'spock' && player2 === 'rock') {
        console.log('Player 1 wins!');
        winner = 'Player 1';
        p1_score += 1;
    }
    else if (player1 === 'rock' && player2 === 'scissors') {
        console.log('Player 1 wins!');
        winner = 'Player 1';
        p1_score += 1;
    }
    //player 2 wins
    else if (player2 === 'scissors' && player1 === 'paper') {
        console.log('Player 2 wins!');
        winner = 'Player 2';
        p2_score += 1;
    }
    else if (player2 === 'paper' && player1 === 'rock') {
        console.log('Player 2 wins!');
        winner = 'Player 2';
        p2_score += 1;
    }
    else if (player2 === 'rock' && player1 === 'lizard') {
        console.log('Player 2 wins!');
        winner = 'Player 2';
        p2_score += 1;
    }
    else if (player2 === 'lizard' && player1 === 'spock') {
        console.log('Player 2 wins!');
        winner = 'Player 2';
        p2_score += 1;
    }
    else if (player2 === 'spock' && player1 === 'scissors') {
        console.log('Player 2 wins!');
        winner = 'Player 2';
        p2_score += 1;
    }
    else if (player2 === 'scissors' && player1 === 'lizard') {
        console.log('Player 2 wins!');
        winner = 'Player 2';
        p2_score += 1;
    }
    else if (player2 === 'lizard' && player1 === 'paper') {
        console.log('Player 2 wins!');
        winner = 'Player 2';
        p2_score += 1;
    }
    else if (player2 === 'paper' && player1 === 'spock') {
        console.log('Player 2 wins!');
        winner = 'Player 2';
        p2_score += 1;
    }
    else if (player2 === 'spock' && player1 === 'rock') {
        console.log('Player 2 wins!');
        winner = 'Player 2';
        p2_score += 1;
    }
    else if (player2 === 'rock' && player1 === 'scissors') {
        console.log('Player 2 wins!');
        winner = 'Player 2';
        p2_score += 1;
    }
    //this is for when the match ends in a draw
    else if (player2 === 'rock' && player1 === 'rock') {
        console.log('Game Draw');
        winner = 'Draw';
    }
    else if (player2 === 'paper' && player1 === 'paper') {
        console.log('Game Draw');
        winner = 'Draw';
    }
    else if (player2 === 'scissors' && player1 === 'scissors') {
        console.log('Game Draw');
        winner = 'Draw';
    }
    else if (player2 === 'lizard' && player1 === 'lizard') {
        console.log('Game Draw');
        winner = 'Draw';
    }
    else if (player2 === 'spock' && player1 === 'spock') {
        console.log('Game Draw');
        winner = 'Draw';
    }
    gameState = 'winner';
    gameLoop();
}
//draws the image for the player selection
function drawPlayerImage(player, x, y) {
    const imageMap = {
        rock: rock,
        paper: paper,
        scissors: scissors,
        lizard: lizard,
        spock: spock
    };
    ctx.drawImage(imageMap[player], x, y, 100, 100);
}
//updated to shorten code
function winScreen() {
    console.log('winner screen');
    if (winner === 'Player 1' || winner === 'Player 2') {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.font = '80px Pixelify Sans';
        ctx.fillStyle = 'green';
        ctx.fillText(p1_score + ' - ' + p2_score, 200, 90);
        ctx.fillText('GAME ', 180, 180);
        ctx.fillText(winner + ' Wins', 50, 250);
    }
    else if (winner === 'Draw') {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.font = '80px Pixelify Sans';
        ctx.fillStyle = 'green';
        ctx.fillText('GAME ' + winner, 100, 230);
    }
    // UPDATE
    ctx.fillRect(20, 20, 100, 100);
    drawPlayerImage(player1, 20, 20);
    ctx.fillRect(480, 20, 100, 100);
    drawPlayerImage(player2, 480, 20);

    
    
    /* // player 1 images for game done
    if (player1 === 'rock') {
        console.log('if show rock');
        ctx.fillRect(20, 20, 100, 100);
        ctx.drawImage(rock, 18, 18, 100, 100);
    }
    else if (player1 === 'paper') {
        console.log('if show rock');
        ctx.fillRect(20, 20, 100, 100);
        ctx.drawImage(paper, 18, 18, 100, 100);
    }
    else if (player1 === 'scissors') {
        console.log('if show rock');
        ctx.fillRect(20, 20, 100, 100);
        ctx.drawImage(scissors, 18, 18, 100, 100);
    }
    else if (player1 === 'lizard') {
        console.log('if show rock');
        ctx.fillRect(20, 20, 100, 100);
        ctx.drawImage(lizard, 18, 18, 100, 100);
    }
    else if (player1 === 'spock') {
        console.log('if show rock');
        ctx.fillRect(20, 20, 100, 100);
        ctx.drawImage(spock, 18, 18, 100, 100);
    }

    //player 2 images game done
    if (player2 === 'rock') {
        console.log('if show rock');
        ctx.fillRect(480, 20, 100, 100);
        ctx.drawImage(rock, 480, 18, 100, 100);
    }
    else if (player2 === 'paper') {
        console.log('if show rock');
        ctx.fillRect(480, 20, 100, 100);
        ctx.drawImage(paper, 480, 18, 100, 100);
    }
    else if (player2 === 'scissors') {
        console.log('if show rock');
        ctx.fillRect(480, 20, 100, 100);
        ctx.drawImage(scissors, 480, 18, 100, 100);
    }
    else if (player2 === 'lizard') {
        console.log('if show rock');
        ctx.fillRect(480, 20, 100, 100);
        ctx.drawImage(lizard, 480, 18, 100, 100);
    }
    else if (player2 === 'spock') {
        console.log('if show rock');
        ctx.fillRect(480, 20, 100, 100);
        ctx.drawImage(spock, 480, 18, 100, 100);
    } */

    ctx.fillRect(130, 310, 280, 80);
    ctx.fillRect(150, 410, 240, 80);
    ctx.font = '40px Pixelify Sans';
    ctx.fillStyle = 'black';
    ctx.fillText('Play Again', 170, 365);
    ctx.fillText('Main Menu', 170, 465);
    setUpClickListener();
}

function gameLoop() {
    if (gameState === 'menu') {
        menuScreen();
    }
    else if(gameState === 'info'){
        infoScreen();
    }
    else if (gameState === 'countDown') {
        chooseTimer();
    }
    else if (gameState === 'winner') {
        winScreen();
    }
}

function infoScreen() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.strokeStyle = 'green';
    ctx.lineWidth = 3;
    ctx.strokeRect(190, 410, 210, 60);
    ctx.font = '60px Pixelify Sans';
    ctx.fillStyle = 'green';
    ctx.fillText('How to play', 130, 100);
    ctx.font = '30px Pixelify Sans';
    ctx.fillText('Back to menu', 200, 450);
    
    displayOptions();
}

function menuScreen() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.font = '80px Pixelify Sans';
    ctx.fillStyle = 'green';
    ctx.fillText('MENU', 190, 180);
    ctx.fillRect(170, 250, 100, 100); // this is the play box
    ctx.fillRect(320, 250, 100, 100); // this is the info box
    ctx.font = '40px Pixelify Sans';
    ctx.fillText('play', 180, 390);
    ctx.fillText('info', 335, 390);
    ctx.fillStyle = 'black';
    ctx.font = '80px Pixelify Sans';
    ctx.fillText('?', 345, 325);

    const play = new Image();

    play.addEventListener("load", () => {
        // Once the image is loaded, draw it onto the canvas
        ctx.drawImage(play, 172, 252, 95, 95);
    });
    play.src = "play.png";


    setUpClickListener();
}
gameLoop();
//menuScreen();
//winScreen();
//displayOptions();
